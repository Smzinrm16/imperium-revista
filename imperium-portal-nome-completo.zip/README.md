# IMPERIUM — Portal híbrido (protótipo)

## Como abrir
Abra `index.html` no navegador. Para testar links de compartilhamento e simular o ambiente publicado, use um servidor local (por exemplo `python -m http.server 8000`).

## Como publicar gratuitamente no GitHub Pages
1. Crie uma conta no https://github.com/ e um repositório público chamado `imperium-portal`.
2. Envie `index.html`, `style.css`, `script.js` e `favicon.svg` para a raiz do repositório.
3. Em Settings > Pages, selecione Deploy from a branch, `main` e `/ (root)`; salve.
4. Aguarde a publicação. O endereço será `https://SEU-USUARIO.github.io/imperium-portal/`.
5. Cadastre o endereço publicado em https://search.google.com/search-console/ e solicite a indexação da página.

## Importante antes de publicar
- Altere o endereço `contato@exemplo.com` no `index.html` por um contato real ou remova o botão.
- Os artigos são demonstrativos e atemporais; não são notícias verificadas em tempo real. Substitua por publicações apuradas com autoria, datas, referências e política de correções.
- Curtidas, enquetes, favoritos e comentários são armazenados apenas em `localStorage` do navegador. **Não são compartilhados entre visitantes**. Para participação pública, será necessário um backend (por exemplo Supabase ou Firebase) com autenticação, moderação e medidas antiabuso.
- O SEO inclui metadados e dados estruturados básicos; aparecer no Google depende da indexação e não é garantido.
- Ao escolher um domínio definitivo, configure URL canônica, sitemap e metadados sociais de imagem.
- As fontes externas são carregadas do Google Fonts; sem internet, o site usa fontes alternativas.

## Estrutura
- `index.html` — marcação e SEO
- `style.css` — design responsivo e animações
- `script.js` — editorias, busca, leitura, enquetes e interações
- `favicon.svg` — ícone

Fundador e proprietário: IGOR SAMUEL DE LIMA MEDEIROS.
